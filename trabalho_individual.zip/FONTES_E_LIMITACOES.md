# Fontes oficiais e decisões de metodologia

## 1. Base quantitativa: Censo 2022 / IBGE

**Apresentação oficial:** "Deslocamentos para trabalho e para estudo — Resultados preliminares da amostra".

- [PDF original do IBGE](https://agenciadenoticias.ibge.gov.br/media/com_mediaibge/arquivos/eb6833eb8d1aa7d4f77b9b38cd20fbdb.pdf)
- [Portal do IBGE sobre o estudo](https://www.ibge.gov.br/estatisticas/Sociais/populacao/22827-censo-demografico-2022.html?edicao=44665)
- [Tabela SIDRA 10332](https://sidra.ibge.gov.br/tabela/10332) — pessoas ocupadas que trabalhavam fora do domicílio, por meio de transporte, escolaridade e cor/raça.

Os CSVs neste repositório reproduzem as **séries numéricas publicadas em gráficos selecionados** na apresentação do IBGE. Eles são transcritos e gerados por `scripts/gerar_bases.py`; **não** são a base integral em microdados ou um arquivo CSV baixado diretamente do SIDRA. Não se afirma que o dataset cubra todos os municípios brasileiros ou todos os cruzamentos possíveis.

| CSV | Quadro oficial reproduzido |
|---|---|
| `modal_por_raca.csv` | "Meio de transporte que passa mais tempo para o trabalho — Cor ou Raça" |
| `tempo_por_renda.csv` | "Tempo de deslocamento entre casa e trabalho — Rendimento Domiciliar Per Capita" |
| `tempo_por_cidade.csv` | "Tempo de deslocamento entre casa e trabalho — Metrópole" (concentrações selecionadas) |
| `modal_por_regiao.csv` | "Meio de transporte para trabalho — Grandes Regiões" |

A maioria dos percentuais soma 100% **dentro da própria categoria** (por exemplo, todas as modalidades em um grupo racial). Pequenas diferenças decorrem do arredondamento publicado.

## 2. Contexto: Ipea — Acesso a Oportunidades

- [Projeto Acesso a Oportunidades](https://www.ipea.gov.br/acessooportunidades/)
- [Dados públicos e documentação](https://www.ipea.gov.br/acessooportunidades/dados/)
- [Publicações](https://www.ipea.gov.br/acessooportunidades/publicacoes/)

O projeto do Ipea associa acessibilidade urbana à possibilidade de chegar a emprego, saúde e educação por diferentes modos de transporte. Os seus estudos embasam a discussão **qualitativa**, não os percentuais das figuras do dashboard, que são do IBGE.

## 3. Definições que protegem a interpretação

- **Renda domiciliar per capita:** rendimento total do domicílio dividido entre seus moradores. Não equivale ao rendimento individual do responsável pelo domicílio.
- **Meio principal:** modo em que a pessoa passa mais tempo no trajeto ao trabalho quando usa mais de um.
- **Mais de 1 hora:** soma das classes de 61–120 e mais de 120 minutos, em pontos percentuais.
- **Mediana no app:** mediana dos percentuais entre categorias (renda, raça, cidades/regiões), não do tempo individual de cada trabalhador.
- **Desvio padrão e variância:** calculados com `ddof=0` (dispersão dos grupos considerados, como população finita desses grupos exibidos).
- **Outlier:** grupo extremo segundo regra de 1,5 × IQR. Não se trata de classificar indivíduos.
- **Sem média nacional simulada:** não somamos faixas de renda ou grupos raciais de tamanhos diferentes como se fossem pessoas na mesma amostra.

## 4. Sobre a frase de 20% da renda com transporte

A imagem de discussão enviada pelo grupo diz que pessoas de menor renda podem gastar até 20% da renda mensal com tarifa de transporte. **Essa afirmação não está demonstrada pelos quadros do IBGE aqui reproduzidos**. Assim, a frase não foi usada como indicador numérico do dashboard; exigiria fonte adicional verificável, com escopo e ano próprios.

## 5. Guia técnico da disciplina

A entrega individual segue a exigência de código Python/ETL, estatísticas, base higienizada e leitura descritiva. O módulo Streamlit é independente e pode ser integrado ao app do grupo; a apresentação conjunta e o relatório final do grupo são outra etapa.
