# Guia rápido: como subir hoje no GitHub

## Pelo site (o mais fácil)

1. No computador, baixe o arquivo ZIP da entrega e extraia-o.
2. Entre no [GitHub](https://github.com) e faça login.
3. Clique em **New repository** e escolha o nome `projeto-integrador-renda-mobilidade`.
4. Deixe o repositório público **somente se sua escola permitir** e clique em **Create repository**.
5. Use **uploading an existing file** (enviar arquivos existentes).
6. Envie **todos os arquivos e pastas que estavam dentro do ZIP** (não envie apenas o `.zip`), mantendo as pastas `src`, `modulos`, `dados`, etc.
7. Clique em **Commit changes**.
8. Copie o link do repositório (ex.: `https://github.com/SEU_USUARIO/projeto-integrador-renda-mobilidade`) e cole no campo da tarefa **Projeto Integrado - Entrega Individual**.

## Alternativa usando Git pelo terminal

Dentro da pasta do projeto:

```bash
git init
git add .
git commit -m "Entrega individual Python e Matematica - renda e mobilidade"
git branch -M main
git remote add origin https://github.com/SEU_USUARIO/projeto-integrador-renda-mobilidade.git
git push -u origin main
```

Substitua `SEU_USUARIO` pelo usuário da sua conta. Se tiver criado o repositório com arquivos anteriores, pode ser necessário sincronizar antes de enviar.

## Conferência antes de entregar

- O repositório mostra o arquivo `app.py` e `requirements.txt`.
- A pasta `dados/tratados` contém os quatro arquivos CSV.
- O `README.md` aparece na página inicial do GitHub.
- Se puder usar computador, confira:

```bash
python -m pip install -r requirements.txt
python -m streamlit run app.py
```

- Se os professores exigirem algum nome específico de arquivo/repositório, siga o nome solicitado na atividade.
- **Não basta entregar a mensagem do chat ou o ZIP aqui:** a entrega solicitada deve ser realizada no GitHub/plataforma da escola.
