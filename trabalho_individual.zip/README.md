# Números que Falam — Rendimento e Mobilidade Urbana

**Projeto Integrador | Python e Matemática | Entrega individual 2026**

**Aluno:** Leonardo Barbosa Silva  
**Turma:** 3E2  
**Indicador:** Transporte e Mobilidade Urbana  
**Tema de discussão:** Rendimento dos Responsáveis e a Captura do Espaço Urbano

> O título da discussão é o do roteiro do grupo. O indicador quantitativo de renda disponível nesta base oficial é **rendimento domiciliar per capita**, que não é igual à renda individual da pessoa responsável pelo domicílio.

## O que o projeto responde?

Como diferenças de renda, raça e localização estão associadas ao tempo gasto para chegar ao trabalho e à escolha do principal transporte utilizado? O painel ajuda os gestores fictícios do trabalho (secretário de Mobilidade, prefeitos e especialistas) a refletir sobre como priorizar investimentos em transporte público, bicicleta e caminhabilidade.

## Dados reais (offline)

As tabelas são transcrições reproduzíveis de **gráficos apresentados pelo IBGE sobre o Censo Demográfico 2022**, não bases inventadas nem preenchidas com valores fictícios. O script `scripts/gerar_bases.py` contém as séries publicadas, suas categorias e a referência oficial, permitindo a regeneração dos CSVs. Os dados tratados já estão incluídos para o aplicativo abrir sem conexão com a Internet.

| Tabela | Registros | Utilização |
|---|---:|---|
| `modal_por_raca.csv` | 35 | Participação (%) do principal transporte por cor ou raça |
| `tempo_por_renda.csv` | 35 | Proporções de duração do trajeto por renda domiciliar per capita |
| `tempo_por_cidade.csv` | 80 | 15 concentrações urbanas selecionadas e a referência Brasil |
| `modal_por_regiao.csv` | 40 | Meios de transporte nas cinco Grandes Regiões |

**Fonte numérica:** [IBGE — Censo Demográfico 2022, Deslocamentos para trabalho e estudo (apresentação)](https://agenciadenoticias.ibge.gov.br/media/com_mediaibge/arquivos/eb6833eb8d1aa7d4f77b9b38cd20fbdb.pdf).  
**Fonte de interpretação:** [Ipea — Projeto Acesso a Oportunidades](https://www.ipea.gov.br/acessooportunidades/).

## Executar no computador

1. Instale **Python 3.10 ou superior**.
2. Extraia o ZIP em uma pasta e abra **essa pasta** no VS Code.
3. No terminal da pasta do projeto:

```bash
python -m pip install -r requirements.txt
python -m streamlit run app.py
```

O Streamlit exibirá um endereço local como `http://localhost:8501`.

**Windows:** caso `python` não funcione, tente `py` no lugar de `python`.

**Testes locais** (após instalar `requirements-dev.txt`):

```bash
python -m pip install -r requirements-dev.txt
python -m pytest -q
```

**Regenerar a base tratada e a análise:**

```bash
python scripts/gerar_bases.py
python scripts/gerar_analise.py
```

## O que foi feito?

- **ETL em Pandas:** leitura de CSV/XLSX, validação, limpeza de percentuais, tratamento de dados inválidos e de duplicatas.
- **NumPy:** média, mediana, moda (quando houver), Q1, Q2, Q3, IQR, amplitude, variância populacional, desvio padrão populacional e outliers pela regra de `1,5 × IQR`.
- **Streamlit:** sidebar com filtro de ano, faixa de renda, UF/cidade, raça, região, meio de transporte e upload de CSV/XLSX que substitui uma das quatro tabelas.
- **Plotly:** gráficos interativos de barras, barras empilhadas, ranking de cidades e boxplot dos percentuais agregados.
- **Interpretação:** análise descritiva e recomendações de política pública com fontes IBGE/Ipea.
- **Integração futura:** o app foi organizado como módulo individual.

## Estrutura

```text
app.py
modulos/
  renda_mobilidade.py         # tela individual Streamlit para usar no dashboard do grupo
src/
  etl.py                    # tratamento das tabelas
  estatisticas.py           # indicadores matemáticos
scripts/
  gerar_bases.py            # tabelas brutas oficiais e geração das tabelas limpas
  gerar_analise.py          # gera análise descritiva numérica
assets/
  mobilidade_urbana.svg     # ilustração original
dados/
   brutos/                 # exportações numéricas reproduzidas da publicação
   tratados/               # CSVs higienizados usados no dashboard
tests/
   test_projeto.py
README.md
ANALISE_DESCRITIVA.md
ROTEIRO_APRESENTACAO.md
COMO_ENTREGAR_NO_GITHUB.md
FONTES_E_LIMITACOES.md
requirements.txt
```

## Como integrar com a etapa em grupo

O integrante responsável por integrar o dashboard pode copiar as pastas `modulos`, `src`, `dados`, `assets` e adicionar a seguinte chamada em seu app principal:

```python
from modulos.renda_mobilidade import renderizar_indicador
renderizar_indicador()
```

O integrador **não deve copiar o comando `st.set_page_config` de `app.py`** se já houver configuração no app do grupo. O `requirements.txt` do grupo deve conter Streamlit, Pandas, NumPy, Plotly, OpenPyXL e Tabulate (para regenerar a análise Markdown).

## Atenção metodológica

1. Todas as proporções são **agregadas**, geralmente calculadas dentro de cada categoria de renda ou raça. Não existem registros individuais de passageiros, nem valores de tempo em minutos para calcular a mediana do trajeto de pessoas.
2. Portanto, as estatísticas do dashboard são aplicadas aos **percentuais observados entre grupos**, não ao tempo individual de deslocamento.
3. A lista de metrópoles é uma **seleção da apresentação**, não a lista completa de todas as cidades brasileiras.
4. Não é correto cruzar as informações de renda por cidade ou raça de forma direta: as tabelas oficiais exibidas neste projeto têm recortes diferentes.
5. A menção a "até 20% da renda gasta em transporte" no roteiro original do grupo **não foi confirmada nesta fonte**; não foi convertida em número de gráfico.
6. Censo 2022: resultados preliminares da amostra. Os percentuais publicados foram arredondados com uma casa decimal.

Para detalhes, consulte `FONTES_E_LIMITACOES.md` e `ANALISE_DESCRITIVA.md`.
