"""Entrada da aplicação individual: streamlit run app.py"""
import streamlit as st
from modulos.renda_mobilidade import renderizar_indicador

st.set_page_config(page_title='Renda e Mobilidade | Números que Falam',page_icon='🚍',layout='wide',initial_sidebar_state='expanded')
renderizar_indicador()
