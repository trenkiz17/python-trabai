from pathlib import Path
from io import BytesIO
import pandas as pd
import numpy as np
import pytest
from src.etl import ler_tabela, higienizar_percentuais
from src.estatisticas import resumo_estatistico, percentual_mais_uma_hora, soma_por_classe_modal

ROOT=Path(__file__).resolve().parents[1]
D=ROOT/'dados'/'tratados'

def dado(nome):return pd.read_csv(D/f'{nome}.csv')

def test_csvs_reais_disponiveis_e_sem_duplicatas():
    schemas={
      'modal_por_raca':['ano','cor_raca','modo'],
      'tempo_por_renda':['ano','faixa_renda','tempo'],
      'tempo_por_cidade':['ano','cidade','uf','tempo'],
      'modal_por_regiao':['ano','regiao','modo'],
    }
    for nome,colunas in schemas.items():
        df=dado(nome)
        assert len(df)>0
        assert df.duplicated(colunas).sum()==0
        assert df['percentual'].between(0,100).all()
        assert df['ano'].nunique()==1 and df['ano'].iloc[0]==2022

def test_cor_raca_fonte_ibge():
    modal=dado('modal_por_raca')
    def v(r,m):
        return modal.query('cor_raca == @r and modo == @m')['percentual'].item()
    assert v('Branca','Automóvel')==42.9
    assert v('Preta','Ônibus')==29.5
    assert v('Indígena','A pé')==32.7

def test_classe_renda_mais_de_uma_hora():
    d=percentual_mais_uma_hora(dado('tempo_por_renda'),'faixa_renda').set_index('faixa_renda')
    assert d.loc['Até 1/4 SM','acima_uma_hora']==pytest.approx(11.7)
    assert d.loc['> 5 SM','acima_uma_hora']==pytest.approx(8.8)

def test_cidades_ranking_rj_sp():
    d=percentual_mais_uma_hora(dado('tempo_por_cidade'),'cidade').set_index('cidade')
    assert d.loc['Rio de Janeiro','acima_uma_hora']==pytest.approx(29.8)
    assert d.loc['São Paulo','acima_uma_hora']==pytest.approx(27.9)
    assert d.loc['Belo Horizonte','acima_uma_hora']==pytest.approx(20.4)

def test_medidas_estatisticas_e_outliers():
    a=resumo_estatistico([2,3,4,5,100])
    assert a['media']==pytest.approx(22.8)
    assert a['mediana']==pytest.approx(4)
    assert a['q1']==pytest.approx(3)
    assert a['q3']==pytest.approx(5)
    assert a['iqr']==pytest.approx(2)
    assert a['amplitude']==pytest.approx(98)
    assert a['variancia']==pytest.approx(np.var([2,3,4,5,100]))
    assert 100 in a['outliers']
    assert a['moda']==[]

def test_modas():
    assert resumo_estatistico([3,2,3,4])['moda']==[3.0]

def test_ajuste_csv_pt_br():
    data=BytesIO('ano;cor_raca;modo;percentual\n2022;Preta;Ônibus;29,5\n'.encode('utf-8'))
    data.name='teste.csv'
    lido=ler_tabela(data)
    out=higienizar_percentuais(lido,['cor_raca','modo'])
    assert out['percentual'].iloc[0]==29.5

def test_upload_xlsx():
    data=BytesIO()
    pd.DataFrame([{'ano':2022,'cor_raca':'Branca','modo':'Automóvel','percentual':42.9}]).to_excel(data,index=False)
    data.seek(0);data.name='dados.xlsx'
    assert ler_tabela(data)['modo'].iloc[0]=='Automóvel'

def test_nao_silenciar_duplicatas():
    df=pd.DataFrame([{'ano':2022,'cor_raca':'Preta','modo':'Ônibus','percentual':29.5}]*2)
    with pytest.raises(ValueError,match='repetidos'):
        higienizar_percentuais(df,['cor_raca','modo'])

def test_limpeza_invalidos():
    df=pd.DataFrame([
        {'ano':'2022','cor_raca':'Preta','modo':'Ônibus','percentual':'29,5'},
        {'ano':'2022','cor_raca':'Branca','modo':'Automóvel','percentual':'-3'},
        {'ano':'2022','cor_raca':'Branca','modo':'Ônibus','percentual':'N/D'},
    ])
    o=higienizar_percentuais(df,['cor_raca','modo'])
    assert len(o)==1
    assert o['percentual'].iloc[0]==29.5

def test_agregacao_coletivo_raca():
    df=soma_por_classe_modal(dado('modal_por_raca'))
    p=df.query("cor_raca == 'Preta' and classe == 'Transporte coletivo'")['percentual'].item()
    assert p==pytest.approx(31.6)
