# Roteiro de fala individual — Português simples

**Indicador:** Transporte e Mobilidade Urbana  
**Tema:** Rendimento dos Responsáveis e a Captura do Espaço Urbano

## Versão para apresentar (aproximadamente 2 minutos)

"Boa noite! Minha parte do nosso projeto é sobre a relação entre **renda, transporte e desigualdade urbana**.

O problema é que nem todo mundo consegue chegar ao trabalho, à escola e aos serviços da cidade com a mesma facilidade. Para entender isso, eu usei dados reais do **Censo 2022 do IBGE**, e também o estudo **Acesso a Oportunidades**, do Ipea.

No primeiro gráfico, eu comparei o **tempo de viagem de acordo com a renda domiciliar por pessoa**. Por exemplo, entre as pessoas com renda domiciliar per capita de até um quarto do salário mínimo, **11,7%** levam mais de uma hora para chegar ao trabalho. Já no grupo com mais de cinco salários mínimos, são **8,8%**. Existe uma diferença de **2,9 pontos percentuais** entre esses dois grupos.

No segundo gráfico, eu analisei o **transporte por raça**. Segundo o IBGE, **42,9% das pessoas brancas** usam o carro como principal meio para chegar ao trabalho, contra **21% das pessoas pretas**. Já no uso do ônibus, são **29,5% das pessoas pretas** e **17,6% das pessoas brancas**.

Também mostrei uma comparação entre cidades. Em locais como **Rio de Janeiro e São Paulo**, muitas pessoas precisam passar mais de uma hora no trajeto de ida ao trabalho.

Em Matemática, eu calculei **média, mediana, quartis, IQR, amplitude e desvio padrão**. O boxplot ajuda a encontrar grupos com valores extremos, conhecidos como outliers. A mediana costuma ser mais resistente a esses extremos do que a média.

Como conclusão, nossa sugestão aos gestores é investir em **transporte público de qualidade, integração entre linhas e acesso a empregos e serviços nos bairros mais afastados**. Não basta melhorar o trânsito para os carros; o objetivo deve ser facilitar a vida de quem mais depende da mobilidade urbana.

Esses resultados mostram desigualdades, mas não significam que a renda ou a raça, sozinhas, sejam as causas de cada deslocamento. Obrigado!"

## Possíveis perguntas dos professores

**1. Qual foi a fonte dos dados?**  
Os percentuais vieram da apresentação oficial do IBGE sobre deslocamento para trabalho no Censo Demográfico 2022. O Ipea foi usado para contextualizar o acesso a oportunidades.

**2. O que você usou de Python?**  
Usei Pandas para tratar os arquivos CSV, NumPy para estatística, Plotly para os gráficos e Streamlit para montar a interface.

**3. Qual a diferença entre média e mediana?**  
A média é a soma dos valores dividida pela quantidade. A mediana é o valor do meio depois que ordenamos os dados. Um valor muito extremo costuma afetar mais a média.

**4. O que é IQR e para que servem os outliers?**  
IQR é Q3 menos Q1. A regra de 1,5 vezes o IQR ajuda a identificar valores fora da faixa esperada. Um outlier não é automaticamente um erro: pode indicar um problema que merece investigação.

**5. Você analisou a renda do responsável pelo domicílio?**  
A expressão faz parte do nosso tema, mas a variável quantitativa da tabela utilizada é a **renda domiciliar por pessoa**, não apenas a do responsável.

**6. Vocês provaram que a falta de dinheiro faz a pessoa usar ônibus?**  
Não. Mostramos associações e diferenças descritivas. Para explicar causas, precisaríamos de outras variáveis e estudos específicos.

**7. Como saber quais cidades têm mais uso da bicicleta?**  
A base principal aqui traz participação por *Grande Região*. O material do IBGE informa que Amapá, Acre e Mato Grosso do Sul tinham os maiores percentuais estaduais de bicicleta, respectivamente 17,4%, 13,3% e 12,6%. Esses são **estados**, não cidades. Para ordenar municípios, seria preciso baixar a tabela completa do SIDRA.

**8. O que é moda nessa análise?**  
É o percentual que aparece com maior frequência nas categorias analisadas. Se nenhum percentual se repete, não existe moda para aquela série.

**9. O que o grupo recomenda aos gestores?**  
Melhorar ônibus, integrar linhas, facilitar caminhada e bicicleta, e avaliar acesso a serviços públicos e empregos nas periferias.
