"""Gera análise descritiva em Markdown a partir dos CSVs tratados."""
from pathlib import Path
import sys
import pandas as pd
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from src.estatisticas import resumo_estatistico,percentual_mais_uma_hora

D=ROOT/'dados'/'tratados'
renda=pd.read_csv(D/'tempo_por_renda.csv')
modal=pd.read_csv(D/'modal_por_raca.csv')
cidade=pd.read_csv(D/'tempo_por_cidade.csv')
renda_longa=percentual_mais_uma_hora(renda,'faixa_renda')
cidade_longa=percentual_mais_uma_hora(cidade.loc[cidade['cidade']!='Brasil'],'cidade')
res_renda=resumo_estatistico(renda_longa['acima_uma_hora'])
res_cidade=resumo_estatistico(cidade_longa['acima_uma_hora'])
carro_branca=float(modal.loc[(modal['cor_raca']=='Branca')&(modal['modo']=='Automóvel'),'percentual'].iloc[0])
carro_preta=float(modal.loc[(modal['cor_raca']=='Preta')&(modal['modo']=='Automóvel'),'percentual'].iloc[0])
onibus_preta=float(modal.loc[(modal['cor_raca']=='Preta')&(modal['modo']=='Ônibus'),'percentual'].iloc[0])
onibus_branca=float(modal.loc[(modal['cor_raca']=='Branca')&(modal['modo']=='Ônibus'),'percentual'].iloc[0])

fmt=lambda v: f'{v:.2f}'.replace('.',',')
texto=f'''# Análise descritiva — Rendimento dos Responsáveis e a Captura do Espaço Urbano

**Indicador técnico do projeto:** Transporte e Mobilidade Urbana (Censo Demográfico 2022).
**Recorte de renda disponível:** *rendimento domiciliar per capita*, não rendimento individual dos responsáveis. 
**Autor da seção:** preencher nome / turma.

## Pergunta de negócio
Como a renda e a cor ou raça se relacionam às condições de deslocamento ao trabalho, e quais localidades merecem atenção prioritária?

## Dados, método e limites
- Fonte numérica: **IBGE, Censo Demográfico 2022**, *Deslocamentos para trabalho e para estudo — Resultados preliminares da amostra*. Os percentuais foram transcritos de quadros oficiais, identificados no código-fonte.
- Fonte de contexto: **Ipea, Projeto Acesso a Oportunidades** — estudos sobre desigualdade territorial, renda e acesso a emprego/serviços.
- A análise usa percentuais **agregados por grupos**. Sem microdados/contagens, não se calcula a mediana do tempo individual dos trabalhadores e não se faz média ponderada de regiões.
- Os valores foram publicados com uma casa decimal; podem não somar exatamente 100% pelo arredondamento.
- O título 'rendimento dos responsáveis' veio da argumentação do grupo, mas a tabela do IBGE aqui utilizada tem como categoria **renda domiciliar por morador**.
- **Não foi verificada** a afirmação de que famílias de baixa renda gastam 'até 20% da renda com transporte'; por isso não foi apresentada como um dado comprovado.

## Comparação por renda
As proporções de viagens **acima de uma hora** (soma de 61–120 minutos e mais de 120 minutos) são:

{renda_longa.to_markdown(index=False)}

A faixa de renda de até 1/4 do salário mínimo registra **11,7%** e a acima de cinco salários mínimos registra **8,8%**, diferença de **2,9 pontos percentuais**. O comportamento varia entre faixas e não deve ser apresentado como uma relação linear perfeita.

**Estatísticas descritivas** das 7 proporções de viagem acima de uma hora, em pontos percentuais:

- Média: **{fmt(res_renda['media'])}**; mediana: **{fmt(res_renda['mediana'])}**; moda: **{'não há' if not res_renda['moda'] else ', '.join(map(fmt,res_renda['moda']))}**.
- Q1: **{fmt(res_renda['q1'])}**; Q2: **{fmt(res_renda['q2'])}**; Q3: **{fmt(res_renda['q3'])}**; IQR: **{fmt(res_renda['iqr'])}**.
- Amplitude: **{fmt(res_renda['amplitude'])}**; variância populacional: **{fmt(res_renda['variancia'])}**; desvio padrão populacional: **{fmt(res_renda['desvio_padrao'])}**.
- Limites 1,5×IQR: **{fmt(res_renda['limite_inferior'])}** a **{fmt(res_renda['limite_superior'])}**; outliers: **{', '.join(map(fmt,res_renda['outliers'])) if res_renda['outliers'] else 'nenhum'}**.

## Comparação por cor/raça
No recorte de meio de transporte predominante durante o trajeto ao trabalho:

- **Automóvel:** pessoas brancas **{fmt(carro_branca)}%** × pessoas pretas **{fmt(carro_preta)}%** — diferença de **{fmt(carro_branca-carro_preta)} p.p.**.
- **Ônibus:** pessoas pretas **{fmt(onibus_preta)}%** × pessoas brancas **{fmt(onibus_branca)}%** — diferença de **{fmt(onibus_preta-onibus_branca)} p.p.**.

Esses percentuais não provam causalidade individual entre raça, renda e veículo. Indicam diferenças de distribuição e ajudam a formular políticas públicas para transporte coletivo e mobilidade ativa.

## Territórios de atenção
Ranking das concentrações urbanas selecionadas pelo IBGE segundo o percentual que leva **mais de uma hora**:

{cidade_longa.sort_values('acima_uma_hora',ascending=False).head(8).to_markdown(index=False)}

**Estatística das 15 concentrações urbanas selecionadas** (excluindo a linha de referência Brasil): média **{fmt(res_cidade['media'])}%**, mediana **{fmt(res_cidade['mediana'])}%**, IQR **{fmt(res_cidade['iqr'])} p.p.**, desvio padrão **{fmt(res_cidade['desvio_padrao'])} p.p.**; {len(res_cidade['outliers'])} outlier(s) pela regra 1,5×IQR. A amostra desta tabela **não representa todas as cidades brasileiras**.

## Recomendações à persona (secretário de Mobilidade e prefeitos)
1. Reforçar frequência e integração do transporte coletivo em corredores com deslocamento longo.
2. Medir oportunidades acessíveis em 30 e 60 minutos por transporte público, especialmente em bairros periféricos, conforme a metodologia do Ipea.
3. Integrar infraestrutura de caminhabilidade e ciclovias a oportunidades de emprego e serviços.
4. Priorizar novos levantamentos desagregados por renda e raça em nível municipal antes de adotar medidas pontuais.

## Referências
- IBGE (2025), apresentação **Deslocamentos para trabalho e para estudo — Resultados preliminares da amostra**, Censo 2022: https://agenciadenoticias.ibge.gov.br/media/com_mediaibge/arquivos/eb6833eb8d1aa7d4f77b9b38cd20fbdb.pdf
- IBGE, tabela SIDRA 10332 (transporte por nível de instrução e cor/raça): https://sidra.ibge.gov.br/tabela/10332
- Ipea, Projeto Acesso a Oportunidades: https://www.ipea.gov.br/acessooportunidades/
- Ipea, dados e metodologia: https://www.ipea.gov.br/acessooportunidades/dados/
'''
(ROOT/'ANALISE_DESCRITIVA.md').write_text(texto,encoding='utf-8')
print('Análise gerada')
