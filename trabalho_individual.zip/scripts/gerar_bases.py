"""Transcreve tabelas/gráficos publicados pelo IBGE para CSV bruto e gera CSV limpo.

Fonte: Censo Demográfico 2022, Deslocamentos para trabalho e para estudo,
Resultados preliminares da amostra (apresentação oficial).
URL: https://agenciadenoticias.ibge.gov.br/media/com_mediaibge/arquivos/eb6833eb8d1aa7d4f77b9b38cd20fbdb.pdf
Dados publicados com 1 casa decimal: soma pode diferir de 100 por arredondamento.
"""
from pathlib import Path
import sys
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from src.etl import higienizar_percentuais

ORIGEM = "IBGE, Censo Demografico 2022 - Deslocamentos para trabalho e para estudo (Resultados preliminares da amostra)"
ANO = 2022

# Os 7 modos agregados e as 5 categorias de cor/raça são os divulgados
# no gráfico "Meio de transporte que passa mais tempo para o trabalho – Cor ou Raça".
MODAL_RACA = {
    'Automóvel': {'Branca':42.9, 'Parda':24.4, 'Preta':21.0, 'Amarela':56.1, 'Indígena':15.0},
    'Ônibus': {'Branca':17.6, 'Parda':23.1, 'Preta':29.5, 'Amarela':12.4, 'Indígena':16.2},
    'Motocicleta': {'Branca':13.6, 'Parda':19.6, 'Preta':15.2, 'Amarela':6.9, 'Indígena':18.6},
    'A pé': {'Branca':15.7, 'Parda':19.3, 'Preta':19.8, 'Amarela':13.9, 'Indígena':32.7},
    'Bicicleta': {'Branca':4.6, 'Parda':7.6, 'Preta':7.8, 'Amarela':2.6, 'Indígena':8.3},
    'Trem ou metrô': {'Branca':1.7, 'Parda':1.4, 'Preta':2.1, 'Amarela':4.7, 'Indígena':0.7},
    'Demais meios': {'Branca':3.9, 'Parda':4.6, 'Preta':4.7, 'Amarela':3.3, 'Indígena':8.5},
}

FAIXAS = ['Até 5 min', '6 a 30 min', '31 a 60 min', '61 a 120 min', 'Mais de 120 min']
# Rendimento domiciliar por pessoa (múltiplos do salário mínimo), não renda
# exclusiva do responsável pelo domicílio.
TEMPO_RENDA = {
    'Até 1/4 SM': [9.6,58.0,20.6,9.8,1.9],
    '> 1/4 a 1/2 SM': [9.1,56.1,21.4,11.3,2.2],
    '> 1/2 a 1 SM': [9.3,56.1,21.2,11.4,2.0],
    '> 1 a 2 SM': [10.4,56.9,20.3,10.7,1.7],
    '> 2 a 3 SM': [12.2,57.4,19.3,9.5,1.5],
    '> 3 a 5 SM': [12.9,57.7,19.4,8.6,1.4],
    '> 5 SM': [12.2,58.9,20.0,7.5,1.3],
}

# Metrópoles/concentrações urbanas selecionadas pela apresentação do IBGE.
# Não são os 27 municípios-capitais nem os 27 estados; refletir isso nos gráficos.
TEMPO_CIDADES = {
    'Brasil': ('BR', [10.4,56.8,20.5,10.5,1.8]),
    'Florianópolis': ('SC', [8.7,61.1,21.9,7.5,0.7]),
    'Goiânia': ('GO', [7.5,55.3,24.3,11.5,1.4]),
    'Porto Alegre': ('RS', [7.3,55.5,25.6,10.9,0.7]),
    'Campinas': ('SP', [5.8,55.6,25.6,12.0,1.0]),
    'Curitiba': ('PR', [6.8,53.5,26.6,12.2,0.9]),
    'Fortaleza': ('CE', [7.1,49.8,28.1,13.9,1.2]),
    'Vitória': ('ES', [6.3,49.5,27.6,15.0,1.6]),
    'Belém': ('PA', [5.7,49.0,27.4,16.0,2.0]),
    'Brasília': ('DF', [5.0,44.0,30.6,19.0,1.3]),
    'Belo Horizonte': ('MG', [5.4,43.4,30.8,18.5,1.9]),
    'Recife': ('PE', [5.1,43.4,30.0,19.2,2.2]),
    'Salvador': ('BA', [4.6,42.1,32.6,18.7,1.9]),
    'Manaus': ('AM', [4.7,40.0,32.5,20.7,2.2]),
    'São Paulo': ('SP', [3.9,36.6,31.6,24.5,3.4]),
    'Rio de Janeiro': ('RJ', [4.3,36.1,29.8,24.2,5.6]),
}

MODAL_REGIAO = {
    'Norte': {'Automóvel':21.8,'Motocicleta':28.5,'A pé':16.4,'Bicicleta':10.0,'Ônibus':16.0,'Trem ou metrô':0.0,'Embarcação pequena':2.1,'Demais meios':5.1},
    'Nordeste': {'Automóvel':21.0,'Motocicleta':26.0,'A pé':23.5,'Bicicleta':6.9,'Ônibus':17.4,'Trem ou metrô':0.3,'Embarcação pequena':0.2,'Demais meios':4.7},
    'Sudeste': {'Automóvel':33.2,'Motocicleta':10.8,'A pé':16.7,'Bicicleta':5.3,'Ônibus':26.6,'Trem ou metrô':3.3,'Embarcação pequena':0.0,'Demais meios':4.0},
    'Sul': {'Automóvel':45.9,'Motocicleta':11.2,'A pé':17.1,'Bicicleta':5.6,'Ônibus':16.4,'Trem ou metrô':0.2,'Embarcação pequena':0.1,'Demais meios':3.4},
    'Centro-Oeste': {'Automóvel':38.8,'Motocicleta':20.0,'A pé':11.3,'Bicicleta':7.5,'Ônibus':18.5,'Trem ou metrô':0.5,'Embarcação pequena':0.0,'Demais meios':3.2},
}

def salvar(nome, dados, colunas_grupo):
    bruto = ROOT/'dados'/'brutos'/f'{nome}.csv'
    tratado = ROOT/'dados'/'tratados'/f'{nome}.csv'
    frame = pd.DataFrame(dados)
    frame.insert(0,'ano',ANO)
    frame['fonte'] = ORIGEM
    frame.to_csv(bruto,sep=';',decimal=',',index=False,encoding='utf-8-sig')
    limpo = higienizar_percentuais(frame, grupos=colunas_grupo)
    limpo.to_csv(tratado,index=False,encoding='utf-8-sig')
    print(nome, len(frame), 'linhas')


def gerar():
    salvar('modal_por_raca', [{'cor_raca':r,'modo':m,'percentual':p} for m, v in MODAL_RACA.items() for r,p in v.items()], ['cor_raca','modo'])
    salvar('tempo_por_renda', [{'faixa_renda':r, 'tempo':t,'percentual':p} for r,v in TEMPO_RENDA.items() for t,p in zip(FAIXAS,v)], ['faixa_renda','tempo'])
    salvar('tempo_por_cidade', [{'cidade':c, 'uf':uf,'tempo':t,'percentual':p} for c,(uf,v) in TEMPO_CIDADES.items() for t,p in zip(FAIXAS,v)], ['cidade','uf','tempo'])
    salvar('modal_por_regiao', [{'regiao':r,'modo':m,'percentual':p} for r,v in MODAL_REGIAO.items() for m,p in v.items()], ['regiao','modo'])

if __name__ == '__main__':
    gerar()
